#!/bin/bash

make Max2VectorInt

echo "-----------------------------------------"
echo "Max2VectorInt serie"
echo "-----------------------------------------"
time ./Max2VectorInt -r 10


