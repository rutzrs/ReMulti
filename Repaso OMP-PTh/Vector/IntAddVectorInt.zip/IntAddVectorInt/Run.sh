#!/bin/bash

make IntAddVectorInt

echo "-----------------------------------------"
echo "IntAddVectorInt serie"
echo "-----------------------------------------"
time ./IntAddVectorInt -r 10


